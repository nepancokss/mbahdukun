import MetaTrader5 as mt5
import yaml
from pathlib import Path

cfg = yaml.safe_load(Path("config/config.yaml").read_text(encoding="utf-8"))
term = cfg.get("terminal", {})
path = term.get("path") or None
if not mt5.initialize(path=path):
    raise SystemExit(f"MT5 initialize failed: {mt5.last_error()}")

try:
    account = mt5.account_info()
    if account is None:
        raise SystemExit(f"No account info: {mt5.last_error()}")
    print("ACCOUNT")
    print(f"  login={account.login} server={account.server}")
    print(f"  currency={account.currency} balance={account.balance} equity={account.equity}")
    print(f"  trade_allowed={account.trade_allowed} trade_expert={account.trade_expert}")
    symbol = cfg["trading"]["symbol"]
    info = mt5.symbol_info(symbol)
    if info is None:
        names = mt5.symbols_get("*XAU*")
        print(f"\nSymbol {symbol!r} not found. Gold-like symbols available:")
        print([x.name for x in (names or [])])
        raise SystemExit("Correct config/config.yaml trading.symbol to the exact broker symbol.")
    mt5.symbol_select(symbol, True)
    tick = mt5.symbol_info_tick(symbol)
    print(f"\nSYMBOL: {symbol}")
    for field in (
        "description", "currency_base", "currency_profit", "currency_margin",
        "digits", "point", "trade_contract_size", "trade_tick_size",
        "trade_tick_value", "trade_tick_value_profit", "trade_tick_value_loss",
        "volume_min", "volume_max", "volume_step", "trade_stops_level",
        "trade_freeze_level", "trade_mode", "trade_calc_mode", "filling_mode",
        "spread", "visible"
    ):
        print(f"  {field}={getattr(info, field, None)}")
    print(f"  bid={getattr(tick, 'bid', None)} ask={getattr(tick, 'ask', None)}")
    print("\nDo not infer contract size or risk from the suffix 'c'.")
    print("The bot sizes positions using MT5 order_calc_profit in the account currency.")
finally:
    mt5.shutdown()
