"""
Simplified candle backtest for CSV OHLC data.
CSV must contain: time, open, high, low, close, spread_points
time must be UTC or parseable as UTC. This is a rough research tool, not a tick-accurate MT5 tester.
It assumes signal at a closed bar and entry on next bar open plus half-spread approximation.
SL/TP execution, gaps, slippage and broker rules are simplified; validate in MT5 Strategy Tester/demo.
"""
import argparse
import pandas as pd
import numpy as np


def ema(s, n):
    return s.ewm(span=n, adjust=False).mean()


def atr(df, n=14):
    pc = df.close.shift(1)
    tr = pd.concat([(df.high-df.low), (df.high-pc).abs(), (df.low-pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1/n, adjust=False, min_periods=n).mean()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("csv", help="M1 OHLC CSV with time,open,high,low,close,spread_points")
    p.add_argument("--lookback", type=int, default=10)
    p.add_argument("--sl-atr", type=float, default=1.5)
    p.add_argument("--tp-atr", type=float, default=1.8)
    p.add_argument("--risk-reward", type=float, default=1.1)
    p.add_argument("--max-bars", type=int, default=5)
    args = p.parse_args()

    df = pd.read_csv(args.csv)
    required = {"time", "open", "high", "low", "close", "spread_points"}
    if not required.issubset(df.columns):
        raise SystemExit(f"CSV missing columns: {required - set(df.columns)}")
    df["time"] = pd.to_datetime(df["time"], utc=True)
    df = df.sort_values("time").drop_duplicates("time").reset_index(drop=True)
    for c in ["open", "high", "low", "close", "spread_points"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna().reset_index(drop=True)
    df["ema9"] = ema(df.close, 9)
    df["ema21"] = ema(df.close, 21)
    df["atr"] = atr(df, 14)
    df["prior_high"] = df.high.shift(1).rolling(args.lookback).max()
    df["prior_low"] = df.low.shift(1).rolling(args.lookback).min()

    trades = []
    i = max(40, args.lookback + 20)
    while i < len(df) - 1:
        r = df.iloc[i]
        if not np.isfinite(r.atr) or r.atr <= 0:
            i += 1
            continue
        side = None
        if r.ema9 > r.ema21 and r.close > r.ema9 and r.close > r.prior_high:
            side = "BUY"
        elif r.ema9 < r.ema21 and r.close < r.ema9 and r.close < r.prior_low:
            side = "SELL"
        if side is None:
            i += 1
            continue

        entry_bar = df.iloc[i+1]
        half_spread = max(0.0, float(entry_bar.spread_points)) * 0.0
        # spread_points is deliberately not converted to price without broker point metadata.
        # User must preprocess `open` prices to include spread or supply `point`-adjusted data.
        entry = float(entry_bar.open) + half_spread if side == "BUY" else float(entry_bar.open) - half_spread
        sl_dist, tp_dist = float(r.atr)*args.sl_atr, float(r.atr)*args.tp_atr
        if tp_dist / sl_dist < args.risk_reward:
            i += 1
            continue
        sl = entry - sl_dist if side == "BUY" else entry + sl_dist
        tp = entry + tp_dist if side == "BUY" else entry - tp_dist
        exit_price, outcome, exit_i = None, "TIME_EXIT", min(i+1+args.max_bars, len(df)-1)
        for j in range(i+1, min(i+1+args.max_bars, len(df))):
            b = df.iloc[j]
            if side == "BUY":
                hit_sl, hit_tp = b.low <= sl, b.high >= tp
            else:
                hit_sl, hit_tp = b.high >= sl, b.low <= tp
            # Conservative assumption if both are hit in same candle: stop first.
            if hit_sl:
                exit_price, outcome, exit_i = sl, "SL", j
                break
            if hit_tp:
                exit_price, outcome, exit_i = tp, "TP", j
                break
        if exit_price is None:
            b = df.iloc[exit_i]
            exit_price = float(b.close)
        signed = (exit_price-entry) if side == "BUY" else (entry-exit_price)
        r_multiple = signed / sl_dist
        trades.append({
            "time": str(r.time), "side": side, "entry": entry, "exit": exit_price,
            "outcome": outcome, "r_multiple_before_costs": r_multiple, "bars_held": exit_i-i
        })
        i = exit_i + 1

    out = pd.DataFrame(trades)
    if out.empty:
        print("No trades generated. Check data/strategy settings.")
        return
    out.to_csv("backtest_trades.csv", index=False)
    wins = out[out.r_multiple_before_costs > 0]
    losses = out[out.r_multiple_before_costs < 0]
    print(f"Trades: {len(out)}")
    print(f"Win rate: {(out.r_multiple_before_costs > 0).mean()*100:.2f}%")
    print(f"Mean R before costs: {out.r_multiple_before_costs.mean():.4f}")
    print(f"Total R before costs: {out.r_multiple_before_costs.sum():.2f}")
    print(f"Profit factor in R before costs: {wins.r_multiple_before_costs.sum()/abs(losses.r_multiple_before_costs.sum()) if len(losses) else float('inf'):.3f}")
    print("WARNING: this is not tick-accurate and does not model real spread, slippage, swaps, commissions, or broker contract values.")
    print("Review backtest_trades.csv and validate with MT5 Strategy Tester and demo forward-test.")


if __name__ == "__main__":
    main()
