from __future__ import annotations

import csv
import json
import logging
import math
import time
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

import feedparser
import MetaTrader5 as mt5
import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config" / "config.yaml"
LOG_DIR = ROOT / "logs"
DATA_DIR = ROOT / "data"
STATE_PATH = DATA_DIR / "state.json"
TRADES_PATH = DATA_DIR / "trades.csv"


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def setup_logging() -> None:
    LOG_DIR.mkdir(exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)sZ %(levelname)s %(message)s",
        handlers=[
            logging.FileHandler(LOG_DIR / "bot.log", encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )


def load_config() -> dict:
    return yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8"))


def state_load() -> dict:
    if STATE_PATH.exists():
        try:
            return json.loads(STATE_PATH.read_text(encoding="utf-8"))
        except Exception:
            logging.exception("State file invalid; stopping to avoid resetting risk counters.")
            raise
    return {}


def state_save(state: dict) -> None:
    DATA_DIR.mkdir(exist_ok=True)
    tmp = STATE_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
    tmp.replace(STATE_PATH)


def ensure_csv_header() -> None:
    if not TRADES_PATH.exists():
        DATA_DIR.mkdir(exist_ok=True)
        with TRADES_PATH.open("w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                "timestamp_utc", "symbol", "signal", "entry", "sl", "tp", "volume",
                "risk_budget_account_ccy", "risk_estimate_account_ccy", "atr",
                "spread_points", "order_ticket", "retcode", "comment"
            ])


def append_trade(row: list) -> None:
    with TRADES_PATH.open("a", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow(row)


def mt5_connect(cfg: dict) -> None:
    term = cfg.get("terminal", {})
    path = term.get("path") or None
    kwargs = {}
    if term.get("login"):
        kwargs["login"] = int(term["login"])
    if term.get("password"):
        kwargs["password"] = str(term["password"])
    if term.get("server"):
        kwargs["server"] = str(term["server"])
    ok = mt5.initialize(path=path, **kwargs)
    if not ok:
        raise RuntimeError(f"mt5.initialize failed: {mt5.last_error()}")
    ti = mt5.terminal_info()
    ai = mt5.account_info()
    if ti is None or ai is None:
        raise RuntimeError(f"Cannot read MT5 terminal/account: {mt5.last_error()}")
    if not ti.connected:
        raise RuntimeError("MT5 terminal is not connected to broker.")
    logging.info("Connected terminal=%s account=%s server=%s currency=%s balance=%s equity=%s",
                 ti.name, ai.login, ai.server, ai.currency, ai.balance, ai.equity)


def verify_account_and_symbol(cfg: dict):
    tcfg = cfg["trading"]
    scfg = cfg["safety"]
    ai = mt5.account_info()
    if ai is None:
        raise RuntimeError("Account info unavailable.")
    if tcfg.get("require_demo_account", True):
        # MT5 exposes trade_mode: 0 demo, 1 contest, 2 real in current Python package.
        if getattr(ai, "trade_mode", None) == mt5.ACCOUNT_TRADE_MODE_REAL:
            raise RuntimeError("LIVE account detected. Bot configured to require a DEMO account.")
    if not tcfg.get("allow_live_trading", False) and getattr(ai, "trade_mode", None) == mt5.ACCOUNT_TRADE_MODE_REAL:
        raise RuntimeError("Live trading is disabled by config.")
    symbol = tcfg["symbol"]
    info = mt5.symbol_info(symbol)
    if info is None:
        available = mt5.symbols_get("*XAU*") or []
        raise RuntimeError(f"Symbol {symbol!r} not found. Gold-like symbols: {[s.name for s in available]}")
    if not info.visible and not mt5.symbol_select(symbol, True):
        raise RuntimeError(f"Could not select symbol {symbol}: {mt5.last_error()}")
    info = mt5.symbol_info(symbol)
    required_positive = ["point", "digits", "trade_tick_size", "volume_min", "volume_max", "volume_step"]
    missing = [f for f in required_positive if getattr(info, f, None) is None or getattr(info, f, 0) <= 0]
    if missing and scfg.get("refuse_if_symbol_spec_incomplete", True):
        raise RuntimeError(f"Incomplete symbol specification {missing}; refusing to trade.")
    tick = mt5.symbol_info_tick(symbol)
    if tick is None or tick.bid <= 0 or tick.ask <= 0 or tick.ask < tick.bid:
        raise RuntimeError("Invalid current tick.")
    logging.info("SYMBOL SPEC %s: digits=%s point=%s contract=%s tick_size=%s tick_value=%s "
                 "tick_value_profit=%s tick_value_loss=%s volume_min=%s volume_max=%s volume_step=%s "
                 "stops_level=%s spread_points=%s account_currency=%s",
                 symbol, info.digits, info.point, info.trade_contract_size, info.trade_tick_size,
                 info.trade_tick_value, getattr(info, "trade_tick_value_profit", None),
                 getattr(info, "trade_tick_value_loss", None), info.volume_min, info.volume_max,
                 info.volume_step, info.trade_stops_level, (tick.ask-tick.bid)/info.point, ai.currency)
    return info


def rates_df(symbol: str, timeframe: int, count: int) -> pd.DataFrame:
    rates = mt5.copy_rates_from_pos(symbol, timeframe, 0, count)
    if rates is None or len(rates) < 50:
        raise RuntimeError(f"Insufficient rates for {symbol}; MT5 error={mt5.last_error()}")
    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    return df


def ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()


def atr(df: pd.DataFrame, period: int) -> pd.Series:
    prev_close = df["close"].shift(1)
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - prev_close).abs(),
        (df["low"] - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr.ewm(alpha=1/period, adjust=False, min_periods=period).mean()


@dataclass
class Signal:
    side: Optional[str]
    atr_value: float
    bar_time: datetime
    reason: str


def make_signal(cfg: dict) -> Signal:
    symbol = cfg["trading"]["symbol"]
    s = cfg["strategy"]
    m1 = rates_df(symbol, mt5.TIMEFRAME_M1, max(100, s["breakout_lookback"] + 40))
    m5 = rates_df(symbol, mt5.TIMEFRAME_M5, 100)

    # Last row is the currently forming candle; use only fully closed bars.
    m1 = m1.iloc[:-1].copy().reset_index(drop=True)
    m5 = m5.iloc[:-1].copy().reset_index(drop=True)
    if len(m1) < 40 or len(m5) < 30:
        return Signal(None, 0.0, utc_now(), "not_enough_closed_bars")

    fast, slow, lookback = int(s["ema_fast"]), int(s["ema_slow"]), int(s["breakout_lookback"])
    m1["ema_fast"] = ema(m1["close"], fast)
    m1["ema_slow"] = ema(m1["close"], slow)
    m1["atr"] = atr(m1, int(s["atr_period"]))
    m5["ema_fast"] = ema(m5["close"], fast)
    m5["ema_slow"] = ema(m5["close"], slow)

    last = m1.iloc[-1]
    previous = m1.iloc[-(lookback+1):-1]
    trend = m5.iloc[-1]
    if pd.isna(last["atr"]) or len(previous) < lookback:
        return Signal(None, 0.0, last["time"].to_pydatetime(), "indicator_warmup")

    # Breakout of prior closed candles, not including the signal candle.
    prior_high = float(previous["high"].max())
    prior_low = float(previous["low"].min())
    buy = (
        trend["ema_fast"] > trend["ema_slow"]
        and last["ema_fast"] > last["ema_slow"]
        and last["close"] > last["ema_fast"]
        and last["close"] > prior_high
    )
    sell = (
        trend["ema_fast"] < trend["ema_slow"]
        and last["ema_fast"] < last["ema_slow"]
        and last["close"] < last["ema_fast"]
        and last["close"] < prior_low
    )
    side = "BUY" if buy else ("SELL" if sell else None)
    reason = f"m1_breakout={side or 'none'} m5_trend={'up' if trend['ema_fast'] > trend['ema_slow'] else 'down'}"
    return Signal(side, float(last["atr"]), last["time"].to_pydatetime(), reason)


def read_calendar_events(path: Path) -> list[dict]:
    if not path.exists():
        return []
    events = []
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            stamp = (row.get("timestamp_utc") or "").strip()
            if not stamp:
                continue
            try:
                dt = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                dt = dt.astimezone(timezone.utc)
            except ValueError:
                logging.warning("Skipping invalid calendar timestamp: %s", stamp)
                continue
            events.append({
                "time": dt,
                "currency": (row.get("currency") or "").upper(),
                "impact": (row.get("impact") or "").lower(),
                "event": row.get("event") or "",
            })
    return events


class NewsFilter:
    def __init__(self, cfg: dict):
        self.cfg = cfg["news"]
        self.last_rss_poll = 0.0
        self.pause_until: Optional[datetime] = None
        self.last_seen_ids: set[str] = set()

    def poll_rss(self) -> None:
        if not self.cfg.get("rss_enabled", True):
            return
        now_mono = time.monotonic()
        if now_mono - self.last_rss_poll < int(self.cfg.get("rss_poll_seconds", 90)):
            return
        self.last_rss_poll = now_mono
        keywords = [str(x).lower() for x in self.cfg.get("keywords", [])]
        lookback = timedelta(minutes=int(self.cfg.get("headline_lookback_minutes", 20)))
        pause = timedelta(minutes=int(self.cfg.get("headline_pause_minutes", 15)))
        for url in self.cfg.get("rss_feeds", []):
            try:
                feed = feedparser.parse(url)
                if getattr(feed, "bozo", False) and not feed.entries:
                    logging.warning("RSS parse issue for %s: %s", url, getattr(feed, "bozo_exception", "unknown"))
                for entry in getattr(feed, "entries", [])[:30]:
                    title = str(entry.get("title", ""))
                    summary = str(entry.get("summary", ""))
                    text = f"{title} {summary}".lower()
                    identity = str(entry.get("id") or entry.get("link") or title)
                    if identity in self.last_seen_ids:
                        continue
                    self.last_seen_ids.add(identity)
                    if len(self.last_seen_ids) > 3000:
                        self.last_seen_ids = set(list(self.last_seen_ids)[-1000:])
                    published = None
                    try:
                        published = datetime(*entry.published_parsed[:6], tzinfo=timezone.utc)
                    except Exception:
                        pass
                    if published and utc_now() - published > lookback:
                        continue
                    if any(k in text for k in keywords):
                        self.pause_until = max(self.pause_until or utc_now(), utc_now() + pause)
                        logging.warning("NEWS PAUSE triggered by headline: %s | %s", title[:200], url)
            except Exception:
                logging.exception("RSS feed failed: %s", url)

    def blocked(self, cfg: dict) -> tuple[bool, str]:
        if not cfg["news"].get("enabled", True):
            return False, "news_filter_disabled"
        self.poll_rss()
        now = utc_now()
        if self.pause_until and now < self.pause_until:
            return True, f"headline_pause_until_{self.pause_until.isoformat()}"
        csv_path = ROOT / cfg["news"].get("calendar_csv", "data/events.csv")
        try:
            events = read_calendar_events(csv_path)
        except Exception:
            logging.exception("Calendar file could not be read.")
            if cfg["safety"].get("refuse_if_news_calendar_unreadable", False):
                return True, "calendar_unreadable"
            events = []
        before = timedelta(minutes=int(cfg["news"].get("blackout_minutes_before", 15)))
        after = timedelta(minutes=int(cfg["news"].get("blackout_minutes_after", 15)))
        high_only = cfg["news"].get("block_high_impact_only", True)
        for event in events:
            if high_only and event["impact"] not in {"high", "3", "red"}:
                continue
            if event["currency"] and event["currency"] not in {"USD", "US"}:
                continue
            if event["time"] - before <= now <= event["time"] + after:
                return True, f"calendar_blackout:{event['event']}@{event['time'].isoformat()}"
        return False, "no_news_blackout"


def current_day_key() -> str:
    # UTC day is used consistently; change only if you intentionally want broker-local day.
    return utc_now().strftime("%Y-%m-%d")


def refresh_risk_state(state: dict, account) -> dict:
    day = current_day_key()
    if state.get("day") != day:
        state["day"] = day
        state["day_start_equity"] = float(account.equity)
        state["trades_today"] = 0
        state["last_trade_epoch"] = 0.0
        logging.info("New UTC day. Daily equity baseline=%s", account.equity)
    state.setdefault("peak_equity", float(account.equity))
    state["peak_equity"] = max(float(state["peak_equity"]), float(account.equity))
    state.setdefault("day_start_equity", float(account.equity))
    state.setdefault("trades_today", 0)
    state.setdefault("last_trade_epoch", 0.0)
    return state


def risk_stop_reason(cfg: dict, state: dict, account) -> Optional[str]:
    t = cfg["trading"]
    day_start = max(float(state["day_start_equity"]), 0.0000001)
    peak = max(float(state["peak_equity"]), 0.0000001)
    daily_loss_pct = max(0.0, (day_start - float(account.equity)) / day_start * 100)
    peak_dd_pct = max(0.0, (peak - float(account.equity)) / peak * 100)
    if daily_loss_pct >= float(t["daily_loss_limit_pct"]):
        return f"daily_loss_limit_hit_{daily_loss_pct:.3f}%"
    if peak_dd_pct >= float(t["peak_drawdown_stop_pct"]):
        return f"peak_drawdown_stop_hit_{peak_dd_pct:.3f}%"
    if int(state["trades_today"]) >= int(t["max_trades_per_day"]):
        return "max_trades_per_day_reached"
    if time.time() - float(state["last_trade_epoch"]) < int(t["cooldown_seconds"]):
        return "cooldown_active"
    return None


def get_positions(symbol: str, magic: int):
    positions = mt5.positions_get(symbol=symbol)
    if positions is None:
        raise RuntimeError(f"positions_get failed: {mt5.last_error()}")
    return [p for p in positions if int(getattr(p, "magic", -1)) == int(magic)]


def round_price(price: float, digits: int) -> float:
    return round(float(price), int(digits))


def floor_volume(volume: float, step: float) -> float:
    if step <= 0:
        return 0.0
    return math.floor((volume + 1e-12) / step) * step


def calc_volume_for_risk(symbol: str, side: str, entry: float, sl: float,
                         risk_budget: float, info) -> tuple[float, float]:
    order_type = mt5.ORDER_TYPE_BUY if side == "BUY" else mt5.ORDER_TYPE_SELL
    loss_one_lot = mt5.order_calc_profit(order_type, symbol, 1.0, entry, sl)
    if loss_one_lot is None:
        raise RuntimeError(f"order_calc_profit failed: {mt5.last_error()}")
    loss_one_lot = abs(float(loss_one_lot))
    if not math.isfinite(loss_one_lot) or loss_one_lot <= 0:
        raise RuntimeError(f"Invalid one-lot SL loss estimate: {loss_one_lot}")
    raw = risk_budget / loss_one_lot
    volume = min(float(info.volume_max), floor_volume(raw, float(info.volume_step)))
    # Do NOT round up to minimum lot: that could exceed the risk budget.
    if volume + 1e-12 < float(info.volume_min):
        return 0.0, loss_one_lot
    # Re-check actual calculated loss at rounded volume.
    loss = mt5.order_calc_profit(order_type, symbol, volume, entry, sl)
    if loss is None:
        raise RuntimeError(f"order_calc_profit volume check failed: {mt5.last_error()}")
    return volume, abs(float(loss))


def pick_filling_mode(info) -> int:
    # Try common modes; order_check validates broker compatibility.
    candidates = [mt5.ORDER_FILLING_IOC, mt5.ORDER_FILLING_FOK, mt5.ORDER_FILLING_RETURN]
    for mode in candidates:
        yield mode


def place_order(cfg: dict, side: str, signal: Signal, info, state: dict, spread_points: float) -> bool:
    symbol = cfg["trading"]["symbol"]
    account = mt5.account_info()
    tick = mt5.symbol_info_tick(symbol)
    if account is None or tick is None:
        logging.error("No account/tick at order time.")
        return False

    entry = float(tick.ask if side == "BUY" else tick.bid)
    s = cfg["strategy"]
    atr_value = float(signal.atr_value)
    sl_dist = max(atr_value * float(s["sl_atr_multiplier"]),
                  float(info.trade_stops_level) * float(info.point) + 2 * float(info.point))
    tp_dist = max(atr_value * float(s["tp_atr_multiplier"]),
                  float(info.trade_stops_level) * float(info.point) + 2 * float(info.point))
    if tp_dist / sl_dist < float(s.get("min_reward_risk", 1.0)):
        logging.info("No trade: reward/risk below configured minimum.")
        return False

    if side == "BUY":
        sl = entry - sl_dist
        tp = entry + tp_dist
    else:
        sl = entry + sl_dist
        tp = entry - tp_dist
    sl, tp = round_price(sl, info.digits), round_price(tp, info.digits)
    if cfg["safety"].get("refuse_if_no_valid_stop", True):
        if side == "BUY" and not (sl < entry < tp):
            logging.error("Invalid BUY SL/TP; refusing.")
            return False
        if side == "SELL" and not (tp < entry < sl):
            logging.error("Invalid SELL SL/TP; refusing.")
            return False

    risk_budget = float(account.equity) * float(cfg["trading"]["risk_per_trade_pct"]) / 100.0
    if risk_budget <= 0:
        logging.error("Invalid risk budget.")
        return False
    volume, loss_estimate = calc_volume_for_risk(symbol, side, entry, sl, risk_budget, info)
    if volume <= 0:
        logging.warning("No trade: broker minimum lot would exceed risk budget. "
                        "risk_budget=%s account_ccy; min_volume=%s; one_lot_loss=%s account_ccy",
                        risk_budget, info.volume_min,
                        mt5.order_calc_profit(mt5.ORDER_TYPE_BUY if side == "BUY" else mt5.ORDER_TYPE_SELL,
                                              symbol, 1.0, entry, sl))
        return False
    if loss_estimate > risk_budget * 1.001:
        logging.error("Calculated volume exceeds risk budget (%s > %s); refusing.", loss_estimate, risk_budget)
        return False

    base_request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "volume": float(volume),
        "type": mt5.ORDER_TYPE_BUY if side == "BUY" else mt5.ORDER_TYPE_SELL,
        "price": entry,
        "sl": sl,
        "tp": tp,
        "deviation": int(cfg["trading"]["max_deviation_points"]),
        "magic": int(cfg["trading"]["magic"]),
        "comment": "LocalXAUScalp",
        "type_time": mt5.ORDER_TIME_GTC,
    }
    # Validate request using order_check before sending. A check does not guarantee fill.
    chosen_request = None
    last_check = None
    for filling in pick_filling_mode(info):
        request = dict(base_request, type_filling=filling)
        check = mt5.order_check(request)
        last_check = check
        if check is not None and int(getattr(check, "retcode", -1)) == 0:
            chosen_request = request
            break
    if chosen_request is None:
        logging.error("order_check rejected all filling modes. Last check=%s error=%s",
                      last_check, mt5.last_error())
        return False

    if not cfg["trading"].get("allow_live_trading", False):
        ai = mt5.account_info()
        if ai and getattr(ai, "trade_mode", None) == mt5.ACCOUNT_TRADE_MODE_REAL:
            logging.error("Safety block: live account; allow_live_trading=false.")
            return False

    logging.warning("ORDER INTENT %s %s volume=%s entry=%s SL=%s TP=%s risk_budget=%s "
                    "risk_estimate=%s account_ccy spread_points=%.1f",
                    side, symbol, volume, entry, sl, tp, risk_budget, loss_estimate, spread_points)
    result = mt5.order_send(chosen_request)
    if result is None:
        logging.error("order_send returned None: %s", mt5.last_error())
        return False
    logging.info("order_send result=%s", result)
    success_codes = {mt5.TRADE_RETCODE_DONE, mt5.TRADE_RETCODE_DONE_PARTIAL, mt5.TRADE_RETCODE_PLACED}
    if result.retcode not in success_codes:
        append_trade([utc_now().isoformat(), symbol, side, entry, sl, tp, volume, risk_budget,
                      loss_estimate, atr_value, spread_points, getattr(result, "order", 0),
                      result.retcode, getattr(result, "comment", "")])
        return False

    state["trades_today"] = int(state.get("trades_today", 0)) + 1
    state["last_trade_epoch"] = time.time()
    state_save(state)
    append_trade([utc_now().isoformat(), symbol, side, entry, sl, tp, volume, risk_budget,
                  loss_estimate, atr_value, spread_points, getattr(result, "order", 0),
                  result.retcode, getattr(result, "comment", "")])
    return True


def run() -> None:
    setup_logging()
    cfg = load_config()
    ensure_csv_header()
    state = state_load()
    news_filter = NewsFilter(cfg)
    mt5_connect(cfg)
    info = verify_account_and_symbol(cfg)
    logging.warning("BOT STARTED. allow_live_trading=%s require_demo_account=%s",
                    cfg["trading"].get("allow_live_trading"), cfg["trading"].get("require_demo_account"))
    last_bar_time = None

    try:
        while True:
            try:
                # Reconnect if terminal or broker connection drops.
                ti = mt5.terminal_info()
                if ti is None or not ti.connected:
                    logging.error("MT5 disconnected; shutting down loop without new orders.")
                    mt5.shutdown()
                    time.sleep(5)
                    mt5_connect(cfg)
                    info = verify_account_and_symbol(cfg)

                account = mt5.account_info()
                if account is None:
                    logging.error("Account info missing; no trade.")
                    time.sleep(2)
                    continue
                state = refresh_risk_state(state, account)
                state_save(state)

                symbol = cfg["trading"]["symbol"]
                tick = mt5.symbol_info_tick(symbol)
                if tick is None or tick.bid <= 0 or tick.ask <= 0:
                    logging.warning("Invalid tick; no trade.")
                    time.sleep(float(cfg["trading"]["poll_seconds"]))
                    continue
                spread_points = (float(tick.ask) - float(tick.bid)) / float(info.point)
                if spread_points > float(cfg["trading"]["max_spread_points"]):
                    logging.info("Spread filter: %.1f points > max %.1f", spread_points,
                                 float(cfg["trading"]["max_spread_points"]))
                    time.sleep(float(cfg["trading"]["poll_seconds"]))
                    continue

                sig = make_signal(cfg)
                if sig.bar_time == last_bar_time:
                    time.sleep(float(cfg["trading"]["poll_seconds"]))
                    continue
                last_bar_time = sig.bar_time

                if sig.side is None:
                    logging.info("No signal | %s", sig.reason)
                    time.sleep(float(cfg["trading"]["poll_seconds"]))
                    continue

                age = (utc_now() - sig.bar_time).total_seconds()
                if age < -2 or age > float(cfg["trading"]["max_signal_age_seconds"]):
                    logging.warning("Stale/future signal age=%.1f sec; skip.", age)
                    time.sleep(float(cfg["trading"]["poll_seconds"]))
                    continue
                atr_points = sig.atr_value / float(info.point)
                if not (float(cfg["trading"]["min_atr_points"]) <= atr_points <=
                        float(cfg["trading"]["max_atr_points"])):
                    logging.info("ATR filter: %.1f points outside configured range.", atr_points)
                    time.sleep(float(cfg["trading"]["poll_seconds"]))
                    continue

                blocked, reason = news_filter.blocked(cfg)
                if blocked:
                    logging.warning("News filter blocked entry: %s", reason)
                    time.sleep(float(cfg["trading"]["poll_seconds"]))
                    continue

                stop = risk_stop_reason(cfg, state, account)
                if stop:
                    logging.warning("Risk stop: %s; no new entry.", stop)
                    time.sleep(float(cfg["trading"]["poll_seconds"]))
                    continue

                positions = get_positions(symbol, int(cfg["trading"]["magic"]))
                if len(positions) >= int(cfg["trading"]["max_positions"]):
                    logging.info("Position cap reached (%s).", len(positions))
                    time.sleep(float(cfg["trading"]["poll_seconds"]))
                    continue

                logging.info("SIGNAL %s | %s | ATR=%.5f spread=%.1f",
                             sig.side, sig.reason, sig.atr_value, spread_points)
                place_order(cfg, sig.side, sig, info, state, spread_points)

            except KeyboardInterrupt:
                raise
            except Exception:
                logging.exception("Loop error; no new order on this iteration.")
            time.sleep(float(cfg["trading"]["poll_seconds"]))
    except KeyboardInterrupt:
        logging.warning("Ctrl+C received; stopping bot. Existing broker-side SL/TP remain active.")
    finally:
        mt5.shutdown()
        logging.info("MT5 shutdown complete.")


if __name__ == "__main__":
    run()
