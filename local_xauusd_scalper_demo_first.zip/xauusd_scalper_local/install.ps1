$ErrorActionPreference = "Stop"
Write-Host "Local XAUUSDc scalper setup (demo-first)"
if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
    throw "Python launcher 'py' not found. Install 64-bit Python 3.12 from python.org and enable Add Python to PATH."
}
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Write-Host ""
Write-Host "Next: open MT5, log into DEMO, enable Algo Trading, then run:"
Write-Host "  .\.venv\Scripts\python.exe inspect_symbol.py"
Write-Host "  .\.venv\Scripts\python.exe bot.py"
Write-Host "Do not enable live trading during validation."
