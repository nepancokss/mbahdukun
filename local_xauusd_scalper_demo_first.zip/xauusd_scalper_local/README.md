# Local XAUUSDc Scalper — demo-first starter

Python + MetaTrader 5 terminal. Strategy: M1 EMA9/EMA21 + ATR + breakout, M5 EMA trend filter, spread/ATR/news filters, risk-sized SL/TP, one-position cap, cooldown, daily stop, logging, and basic CSV backtest.

## Important limits
- This is a starter implementation, not a profitable or production-certified strategy.
- `allow_live_trading: false` and `require_demo_account: true` are intentional. Keep them while testing.
- "Very high" means more frequent signal seeking; it must not mean unlimited leverage or oversized lots.
- Symbol suffixes like `XAUUSDc` do not define contract size. Run `inspect_symbol.py` and verify every field against the broker's contract specification.
- Lot size is based on `mt5.order_calc_profit()` in the account currency reported by MT5. If the broker's minimum volume exceeds the risk budget, the bot skips the trade rather than rounding up.
- The default equity value in the request (700 USC) is NOT hard-coded. The bot reads actual MT5 account equity and account currency on every run.
- News: RSS headlines are a supplemental pause filter. The economic calendar CSV must be maintained from a reliable source. This package does not magically have a guaranteed live economic calendar feed.
- The included candle backtest is deliberately simplified. Use MT5 Strategy Tester with real ticks where available, then demo forward-test.

## 1. Install on Windows Server 2025
1. Install 64-bit Python 3.12.
2. Install the MT5 desktop terminal and log into the intended DEMO account.
3. In MT5, enable Algo Trading if required by your terminal policy.
4. Copy this folder to e.g. `C:\trade\local-xau-scalper`.
5. Open PowerShell in that folder and run:
   ```powershell
   Set-ExecutionPolicy -Scope Process Bypass
   .\install.ps1
   ```
6. Inspect broker symbol/account details:
   ```powershell
   .\.venv\Scripts\python.exe inspect_symbol.py
   ```
7. Confirm the exact symbol name, account currency, equity, contract size, tick size/value, min/max/step volume, stop level, and spread. If the symbol isn't found, edit `config\config.yaml`.
8. Review `config\config.yaml`. Leave `allow_live_trading: false`, `require_demo_account: true`.
9. Start:
   ```powershell
   .\.venv\Scripts\python.exe bot.py
   ```
10. Stop with Ctrl+C. Broker-side SL/TP on existing positions remain active.

## 2. Economic calendar
`data/events.csv` columns:
`timestamp_utc,currency,impact,event,actual,forecast,previous`

Example format only (not an actual event):
```csv
timestamp_utc,currency,impact,event,actual,forecast,previous
2026-10-20T12:30:00Z,USD,high,Example US inflation release,,,
```
Use UTC timestamps, and update the file from a reliable calendar source. The bot blocks entries within the configured minutes before/after high-impact USD events. Validate timezone conversions carefully. Do not paste fabricated event times.

RSS feeds are configurable in `config/config.yaml`; network access is required to retrieve them. The headline filter pauses entries when a recent headline matches configured keywords. RSS is not a substitute for an economic calendar and does not guarantee that every important news item is detected.

## 3. Safety logic
- Uses actual MT5 equity and currency.
- Calculates loss for 1 lot with `order_calc_profit` from proposed entry to stop, then floors volume to broker step.
- Refuses to trade if minimum lot would exceed the configured risk budget.
- Checks `order_check` before `order_send`.
- Does not open if a position with the same symbol + magic exists.
- Stops new entries when daily loss, peak drawdown, or daily trade cap is reached.
- Spread/ATR filters and a cooldown reduce rapid re-entry.
- Existing positions are not force-closed by the daily stop; SL/TP remain broker-side.

Risk limits are approximate. Actual loss may exceed the modeled risk because of gaps, slippage, spread widening, and execution. The bot currently assumes one instance owns the configured magic number. Do not run multiple copies against the same account/magic.

## 4. Test plan
1. Run `inspect_symbol.py` and save output.
2. Run bot on DEMO only. Confirm no order is sent on an unknown symbol or real account.
3. Test that high spread, stale ticks, missing bars, news blackout, and daily loss stops block entries.
4. Run at least several weeks of historical data through MT5 Strategy Tester with real ticks if available.
5. Compare: baseline technical strategy vs. news filter enabled. Keep the news filter only if measured results improve.
6. Forward-test demo across sessions and high-impact releases; review `logs/bot.log` and `data/trades.csv`.
7. Do not switch to live solely because of a short profitable run. Re-check broker specifications and minimum-lot risk first.

## 5. Basic CSV backtest
Export M1 OHLC data to CSV with columns:
`time,open,high,low,close,spread_points`

Then:
```powershell
.\.venv\Scripts\python.exe backtest.py .\data\m1.csv
```
This backtest is a rough signal research tool. It does not reproduce MT5 execution, and `spread_points` is not converted to price because broker point metadata is required. Do not interpret its output as a live performance estimate.

## 6. Operational notes
- Use Windows Task Scheduler only after the bot behaves correctly manually. Configure restart-on-failure and log rotation.
- Keep the MT5 terminal open and connected. Python's MT5 package communicates with the installed terminal.
- Avoid storing broker passwords in this project or committing them to Git.
- This bot is not an AI/ML model yet; it is a transparent rule-based scalper. Add ML only after collecting timestamp-correct data and proving out-of-sample improvement.
